async function api(path, method='GET', body) {
  const res = await fetch('/api' + path, {
    method,
    headers: body ? {'Content-Type':'application/json'} : undefined,
    body: body ? JSON.stringify(body) : undefined
  });
  return res.json();
}

async function refresh() {
  const slots = await api('/slots');
  const slotsDiv = document.getElementById('slots');
  slotsDiv.innerHTML = '';
  slots.forEach(s => {
    const d = document.createElement('div');
    d.className = 'slot' + (s.occupied ? ' occupied' : '');
    d.innerHTML = `<strong>Slot ${s.id}</strong><br/>${s.occupied ? s.vehicle_number + '<br/>' + new Date(s.entry_time).toLocaleString() : 'Free'}`;
    slotsDiv.appendChild(d);
  });
  const logs = await api('/logs');
  const logsDiv = document.getElementById('logs');
  logsDiv.innerHTML = '';
  logs.forEach(l => {
    const div = document.createElement('div');
    div.className = 'log-item';
    div.innerText = `${l.vehicle_number} — Slot ${l.slot_id} — In: ${l.entry_time ? new Date(l.entry_time).toLocaleString() : '-'} Out: ${l.exit_time ? new Date(l.exit_time).toLocaleString() : '-'} Fee: ${l.fee || 0}`;
    logsDiv.appendChild(div);
  });
  const summary = await api('/summary');
  document.getElementById('summary').innerText = `Total slots: ${summary.total} | Occupied: ${summary.occupied} | Free: ${summary.free}`;
}

document.getElementById('entryBtn').addEventListener('click', async () => {
  const v = document.getElementById('vehicleInput').value.trim();
  if (!v) return alert('Enter vehicle number');
  const res = await api('/entry', 'POST', {vehicle_number: v});
  if (res.error) alert(res.error); else { alert(`Assigned slot ${res.slot_id}`); document.getElementById('vehicleInput').value=''; refresh(); }
});

document.getElementById('exitBtn').addEventListener('click', async () => {
  const v = document.getElementById('vehicleInput').value.trim();
  if (!v) return alert('Enter vehicle number');
  const res = await api('/exit', 'POST', {vehicle_number: v});
  if (res.error) alert(res.error); else { alert(`Exit registered. Fee: ${res.fee}`); document.getElementById('vehicleInput').value=''; refresh(); }
});

refresh();
setInterval(refresh, 5000);