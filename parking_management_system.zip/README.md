# Vehicle Parking Management System

A simple Parking Management System built with **Node.js (Express)** and **SQLite** with a static frontend.

## Features
- Register vehicle entry (assigns first free slot).
- Register vehicle exit (calculates fee, frees slot).
- View real-time slot availability and recent logs.
- Simple summary (total, occupied, free).

## Tech
- Backend: Node.js + Express
- Database: SQLite
- Frontend: Static HTML/CSS/JS (served from Express)

## Setup (locally)
1. Make sure you have Node.js installed (v14+ recommended).
2. Extract the project and open terminal in the project folder.
3. Install dependencies:
```bash
npm install
```
4. Start the server:
```bash
npm start
```
5. Open `http://localhost:3000` in your browser.

## Notes
- Default parking slots: 20 (created automatically).
- Rate per hour: 20 (see `server.js` RATE_PER_HOUR).
- This is a minimal demo. For production use, add authentication, validation, tests, and deploy securely.